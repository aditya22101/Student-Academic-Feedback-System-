with open('feedback_results.txt', 'r') as file:
    contents = file.read()

print(contents)
