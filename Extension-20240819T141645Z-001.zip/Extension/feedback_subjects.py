from tkinter import *
from tkinter import ttk
from tkinter import messagebox

root = Tk()
root.title("Feedback")
frame_header = ttk.Frame(root)
frame_header.pack()
headerlabel = ttk.Label(frame_header,text ='Student Feedback', foreground='blue',font=('Arial',56))
headerlabel.grid(row=0,column=3)
messagelabel= ttk.Label(frame_header,text='PLEASE TELL US WHAT YOU THINK',foreground='green',font=('Arial',24))
messagelabel.grid(row=1,column=3)

frame_content = ttk.Frame(root)
frame_content.pack()
# def submit ():
 # username = entry_name.get()
 # print(username)

myvar = StringVar()
var = StringVar()
# cmnt = stringvar()
namelabel = ttk.Label(frame_content,text='Name')
namelabel.grid(row=0,column=0,sticky='sw')
entry_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
entry_name.grid(row=1,column=0)
emaillabel = ttk.Label(frame_content,text='Email')
emaillabel.grid(row=0,column=2,sticky='sw')
entry_email = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=var)
entry_email.grid(row=1,column=2)

subject = ttk.Label(frame_content,text='Subject',font=('Arial',18))
subject.grid(row=3,column=0,sticky='sw')
sub_name = ttk.Label(frame_content,width=22,font=('Arial,18'),text="OOP")
sub_name.grid(row=6,column=0)
sub_name = ttk.Label(frame_content,width=22,font=('Arial,18'),text="Quantum Mechanics")
sub_name.grid(row=8,column=0)
sub_name = ttk.Label(frame_content,width=22,font=('Arial,18'),text="Calculus")
sub_name.grid(row=10,column=0)
sub_name = ttk.Label(frame_content,width=22,font=('Arial,18'),text="IOT")
sub_name.grid(row=12,column=0)
sub_name = ttk.Label(frame_content,width=22,font=('Arial,18'),text="3D Printing")
sub_name.grid(row=14,column=0)
fac = ttk.Label(frame_content,text='Faculty',font=('Arial',18))
fac.grid(row=3,column=1,sticky='sw')
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=6,column=1)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=8,column=1)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=10,column=1)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=12,column=1)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=14,column=1)
com = ttk.Label(frame_content,text='Comment',font=('Arial',18))
com.grid(row=3,column=2,sticky='sw')
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=6,column=2)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=8,column=2)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=10,column=2)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=12,column=2)
fac_name = ttk.Entry(frame_content,width=22,font=('Arial,18'),textvariable=myvar)
fac_name.grid(row=14,column=2)
# textcomment = Text(frame_content,width=75,height=20)
# textcomment.grid(row=9,column=0,columnspan=2)

# textcomment.config(wrap='word')
# def clear():
# textcomment.delete(1.0,'end')

def clear():
    global entry_name
    global entry_email
    # global textcomment
    messagebox.showinfo(title='clear',message='Do You want to clear?')

    entry_name.delete(0,END)
    entry_email.delete(0,END)
    # textcomment.delete(1.0,END)

def submit():
    global entry_name
    global entry_email
    global textcomment
    print('Name : {}'.format(myvar.get()))
    print('Email: {}'.format(var.get()))
    print('Comment : {}'.format(textcomment.get(1.0,END)))
    messagebox.showinfo(title='Submit',message='Thank You for your feedback , Your Comment submitted')
    entry_name.delete(0,END)
    entry_email.delete(0,END)
    # textcomment.delete(1.0,END)

Submitbutton = ttk.Button(frame_content,cursor="hand2",text='Submit',command=submit).grid(row=18,column=0,sticky='e')
clearbutton = ttk.Button(frame_content,text='Clear',cursor="hand2",command=clear).grid(row=18,column=1,sticky='w')


# f = open("adi.txt","w")
# f.write(f"{print('Comment : {}'.format(textcomment.get(1.0,END)))}")
# f.close()
mainloop()