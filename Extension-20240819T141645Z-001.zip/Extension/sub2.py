import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import subprocess
import csv





class FeedbackForm:
    def __init__(self, root):
        self.root = root
        self.root.title("Feedback")
        self.root.geometry("1199x600+90+45")
        self.root.configure(bg="light yellow")
        # self.bg=PhotoImage(file=r""C:\Users\adity\OneDrive\Pictures\Screenshots\Screenshot 2023-06-26 184845.png")
        # self.bg_image=Label(self.root,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)
        # Frame_login = Frame(self.root,bg="White")
        # Frame_login.place(x=330,y=150,width=500,height=400)
        

        # Frame_login = Frame(self.root,bg="White")
        # Frame_login.place(x=330,y=150,width=500,height=400)
        self.create_widgets()

    def create_widgets(self):
        self.frame_header = ttk.Frame(self.root)
        self.frame_header.pack(pady=10)

        self.header_label = ttk.Label(self.frame_header, text='Student Feedback', foreground='blue',background='pink', font=('Arial', 40, 'bold'))
        self.header_label.pack()

        self.frame_content = ttk.Frame(self.root)
        self.frame_content.pack(pady=10)
        self.frame_content.configure(style="Content.TFrame")
        style = ttk.Style()
        style.configure("Header.TFrame", background="light pink")  # Set background color for frame_header
        style.configure("Content.TFrame", background="light yellow")  # Set background color for frame_content


        self.name_label = ttk.Label(self.frame_content, text='Name:', font=('Arial', 18))
        self.name_label.grid(row=0, column=0, sticky='w')
        self.entry_name = ttk.Entry(self.frame_content, width=30, font=('Arial', 14))
        self.entry_name.grid(row=0, column=1, padx=10, pady=5)

        self.email_label = ttk.Label(self.frame_content, text='Email:', font=('Arial', 18))
        self.email_label.grid(row=1, column=0, sticky='w')
        self.entry_email = ttk.Entry(self.frame_content, width=30, font=('Arial', 14))
        self.entry_email.grid(row=1, column=1, padx=10, pady=5)

        self.subject_label = ttk.Label(self.frame_content, text='Subject:', font=('Arial', 18))
        self.subject_label.grid(row=2, column=0, sticky='w')
        subjects = ["OOP", "Quantum Mechanics", "Calculus", "IOT", "3D Printing","AIML","CDS","OT"]
        self.subject_combobox = ttk.Combobox(self.frame_content, values=subjects, font=('Arial', 14))
        self.subject_combobox.grid(row=2, column=1, padx=10, pady=5)

        self.faculty_label = ttk.Label(self.frame_content, text='Faculty:', font=('Arial', 18))
        self.faculty_label.grid(row=3, column=0, sticky='w')
        self.entry_faculty = ttk.Entry(self.frame_content, width=30, font=('Arial', 14))
        self.entry_faculty.grid(row=3, column=1, padx=10, pady=5)

        self.comment_label = ttk.Label(self.frame_content, text='Comment:', font=('Arial', 18))
        self.comment_label.grid(row=4, column=0, sticky='w')
        self.text_comment = tk.Text(self.frame_content, width=40, height=10, font=('Arial', 12))
        self.text_comment.grid(row=4, column=1, padx=10, pady=5)
        self.rating_label = ttk.Label(self.frame_content, text='Rating:', font=('Arial', 18))
        self.rating_label.grid(row=5, column=0, sticky='w')
        self.rating_scale = Scale(self.frame_content, from_=1, to=5, orient=tk.HORIZONTAL, length=200, tickinterval=1, font=('Arial', 14))
        self.rating_scale.grid(row=5, column=1, padx=10, pady=5)


        self.submit_button = ttk.Button(self.frame_content, text='Next', cursor="hand2", command=self.submit, width=10)
        self.submit_button.grid(row=7, column=0, sticky='e', padx=10, pady=10)

        self.clear_button = ttk.Button(self.frame_content, text='Clear', cursor="hand2", command=self.clear, width=10)
        self.clear_button.grid(row=7, column=1, sticky='w', padx=10, pady=10)

    def clear(self):
        self.entry_name.delete(0, tk.END)
        self.entry_email.delete(0, tk.END)
        self.text_comment.delete("1.0", tk.END)
        self.rating_scale.set(1)

    def save_feedback_to_csv(self, name, email, subject, faculty, comment, rating):
        fieldnames = ["Name", "Email", "Subject", "Faculty", "Comment", "Rating"]
        with open('feedback.csv', 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            # Write column headers in the first row
            if file.tell() == 0:
                writer.writeheader()

            writer.writerow({
                "Name": name,
                "Email": email,
                "Subject": subject,
                "Faculty": faculty,
                "Comment": comment,
                "Rating": rating
            })


    def submit(self):
        name = self.entry_name.get()
        email = self.entry_email.get()
        subject = self.subject_combobox.get()
        faculty = self.entry_faculty.get()
        comment = self.text_comment.get("1.0", tk.END)
        rating = self.rating_scale.get()

        print('Name:', name)
        print('Email:', email)
        print('Subject:', subject)
        print('Faculty:', faculty)
        print('Comment:', comment)
        print('Rating:', rating)
        self.save_feedback_to_csv(name, email, subject, faculty, comment, rating)
        # messagebox.showinfo(title='Submit', message='Thank you for your feedback. Your comment has been submitted.')
        subprocess.Popen(['python', r'C:\Users\adity\C Language\Python\Project in Python\am.py'])

        self.clear()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    root = tk.Tk()
    feedback_form = FeedbackForm(root)
    feedback_form.run()
