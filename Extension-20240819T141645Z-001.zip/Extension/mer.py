import csv

def merge_csv_column_wise(file1, file2, output_file):
    with open(file1, 'r') as f1, open(file2, 'r') as f2, open(output_file, 'w', newline='') as outfile:
        reader1 = csv.reader(f1)
        reader2 = csv.reader(f2)
        writer = csv.writer(outfile)

        for row1, row2 in zip(reader1, reader2):
            merged_row = row1 + row2  # Concatenate the rows column-wise
            writer.writerow(merged_row)

        # If there are remaining rows in file2, append them to the output file
        for row2 in reader2:
            writer.writerow([''] * len(row1) + row2)  # Pad empty values in file1 columns

merge_csv_column_wise('feedback.csv', 'feedback_text.csv', 'merged.csv')
