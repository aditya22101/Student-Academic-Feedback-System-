import csv

def calculate_average_ratings():
    subject_ratings = {}

    with open('feedback.csv', 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            subject = row['Subject']
            rating = row['Rating']

            # Skip rows with missing or non-numeric ratings
            if rating is None or not rating.isdigit():
                continue

            rating = float(rating)

            if subject in subject_ratings:
                subject_ratings[subject].append(rating)
            else:
                subject_ratings[subject] = [rating]

    for subject, ratings in subject_ratings.items():
        average_rating = sum(ratings) / len(ratings)
        print(f"Subject: {subject}, Average Rating: {average_rating:.2f}")

if __name__ == "__main__":
    calculate_average_ratings()
