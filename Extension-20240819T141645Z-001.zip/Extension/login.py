from tkinter import *
from PIL import ImageTk
from tkinter import messagebox
import subprocess

class Login:
    def __init__(self, root):
        self.root = root
        self.root.title("Login System")
        self.root.geometry("1199x600+90+45")

        self.bg=PhotoImage(file=r"C:\Users\adity\OneDrive\Pictures\Screenshots\Screenshot 2023-06-20 155153.png")
        self.bg_image=Label(self.root,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)
        Frame_login = Frame(self.root,bg="White")
        Frame_login.place(x=330,y=150,width=500,height=400)

        title = Label(Frame_login,text="IIIT Naya Raipur",font=("Goudy old style",15,"bold"),fg="black",bg="white").place(x=200,y=10)
        
        title = Label(Frame_login,text="Login Here",font=("Impact",25,"bold"),fg="green",bg="white").place(x=200,y=40)
        subtitle = Label(Frame_login,text="User Login Area",font=("Goudy old style",15,"bold"),fg="black",bg="white").place(x=90,y=100)

        lbl_user = Label(Frame_login,text="Username",font=("Goudy old style",15,"bold"),fg="brown",bg="white").place(x=90,y=140)

        self.username = Entry(Frame_login,font=("Goudy old style",15,"bold"),bg="#E7E6E6")
        self.username.place(x=90,y=170,width=320,height=35)

        lbl_password = Label(Frame_login,text="Password",font=("Goudy old style",15,"bold"),fg="brown",bg="white").place(x=90,y=210)

        self.password = Entry(Frame_login,font=("Goudy old style",15,"bold"),bg="#E7E6E6")
        self.password.place(x=90,y=240,width=320,height=35)

        forget = Button(Frame_login,text="Forget Password?",bd=0,cursor="hand2",font=("Goudy old style",12),fg="blue",bg="white").place(x=90,y=280)
        submit = Button(Frame_login,command=self.check_function,text="Login?",bd=0,cursor="hand2",font=("Goudy old style",15),bg="blue",fg="white").place(x=90,y=320,height=40,width=180)

    def check_function(self):
     if self.username.get() == "" or self.password.get() == "":
        messagebox.showerror("Error", "All fields are required", parent=self.root)
     elif self.username.get() != "IIIT_NR" or self.password.get() != "iiitnr":
        messagebox.showerror("Error", "Invalid username or password", parent=self.root)
     else:
        messagebox.showinfo("Welcome", f"Welcome {self.password.get()}")
        root.destroy()  # Close the login window
      #   root_feedback = Tk()  # Create a new window for the feedback form
        # feedback_form = FeedbackForm(root_feedback)
        # feedback_form.run()
        subprocess.Popen(['python', r'C:\Users\adity\C Language\Python\Project in Python\sub2.py'])


root = Tk()
obj = Login(root)
root.mainloop()
from datetime import datetime

current_datetime = datetime.now()
formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print(formatted_datetime)

