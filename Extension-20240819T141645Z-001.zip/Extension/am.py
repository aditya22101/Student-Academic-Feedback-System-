import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import json
import csv


class Question:
    def __init__(self, question, options):
        self.question = question
        self.options = options


class FeedbackForm:
    def __init__(self, root, questions):
        self.root = root
        self.questions = questions
        self.answers = {}

        self.root.title("Feedback")
        self.create_widgets()

    def create_widgets(self):
        self.frame_content = ttk.Frame(self.root)
        self.frame_content.pack(pady=10)

        for i, question in enumerate(self.questions):
            label = ttk.Label(self.frame_content, text=question.question, font=('Arial', 12))
            label.grid(row=i, column=0, sticky='w', padx=5, pady=5)

            options = ttk.Combobox(self.frame_content, values=question.options, font=('Arial', 12))
            options.grid(row=i, column=1, padx=5, pady=5)
            options.bind("<<ComboboxSelected>>", lambda event, index=i, combo=options: self.handle_selection(event, index, combo))

        self.submit_button = ttk.Button(self.frame_content, text='Submit', cursor="hand2", command=self.submit)
        self.submit_button.grid(row=len(self.questions), column=0, sticky='e', padx=5, pady=10)

        self.clear_button = ttk.Button(self.frame_content, text='Clear', cursor="hand2", command=self.clear)
        self.clear_button.grid(row=len(self.questions), column=1, sticky='w', padx=5, pady=10)

    def handle_selection(self, event, index, combo):
        self.answers[index] = combo.get()

    def submit(self):
        fieldnames = ["Content", "Instructor", "Assignment", "Overall"]

        with open('feedback_text.csv', 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            # Write column headers in the first row
            if file.tell() == 0:
                writer.writeheader()

            writer.writerow({
                "Content": self.answers.get(0, "Not answered"),
                "Instructor": self.answers.get(1, "Not answered"),
                "Assignment": self.answers.get(2, "Not answered"),
                "Overall": self.answers.get(3, "Not answered")
            })

        messagebox.showinfo(title='Submit', message='Thank you for your feedback. Your responses have been submitted.')
        self.clear()

    def clear(self):
        self.answers = {}
        for child in self.frame_content.winfo_children():
            if isinstance(child, ttk.Combobox):
                child.set("")


def load_questions_from_json(file_path):
    with open(file_path) as file:
        data = json.load(file)
        feedback_questions = data["feedback_questions"]

        questions = []
        for question_data in feedback_questions:
            question = Question(question_data["question"], question_data["options"])
            questions.append(question)

        return questions


if __name__ == "__main__":
    root = tk.Tk()

    # Load questions from the JSON file
    questions = load_questions_from_json(r"C:\Users\adity\C Language\Python\Project in Python\feed.json")

    # Create an instance of the FeedbackForm class
    feedback_form = FeedbackForm(root, questions)
    feedback_form.root.mainloop()
